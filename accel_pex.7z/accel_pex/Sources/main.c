#include "Cpu.h"
#include "Events.h"
#include "Pins1.h"
#include "FX1.h"
#include "GI2C1.h"
#include "WAIT1.h"
#include "KSDK1.h"
#include "CI2C1.h"
#include "CsIO1.h"
#include "IO1.h"
#include "UTIL1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "PDD_Includes.h"
#include "Init_Config.h"
/* User includes (#include below this line is not maintained by Processor Expert) */

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */

int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */
  FILE *values;
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */


  int16_t x,y,z,xm,ym,zm;
  int16_t value1, value2, value3, addr;
  uint8_t ret;
  byte res = ERR_OK;
  int16_t *data[3];
  uint8_t who, temp;
  uint16_t magX, magY, magZ;

  FX1_Init();
  //FILE *fopen(const char *filename, const char *mode);
  //values=fopen("c:\\value.txt", "w");

  for(;;) {
        /* get WHO AM I values */

      if (FX1_WhoAmI(&who)!=ERR_OK) {
          return ERR_FAILED;
      }

      //printf("Who Am I  value in decimal \t: %4d\n",who);
      for(xm=0;xm<=30000;xm++); //delay


      /* get raw temperature values */

      if (FX1_GetTemperature(&temp)!=ERR_OK) {
                return ERR_FAILED;
            }

      //printf("RAW Temperature value in decimal \t: %4d\n",temp);
       for(xm=0;xm<=30000;xm++);  //delay



//set up registers for accelerometer and magnetometer values

      if (FX1_WriteReg8(FX1_CTRL_REG_1, 0x00) != ERR_OK) {
          return ERR_FAILED;
      }
      if (FX1_WriteReg8(FX1_M_CTRL_REG_1, 0x1F) != ERR_OK) {
          return ERR_FAILED;
      }
      if (FX1_WriteReg8(FX1_M_CTRL_REG_2, 0x20) != ERR_OK) {
          return ERR_FAILED;
      }
      if (FX1_WriteReg8(FX1_XYZ_DATA_CFG, 0x00) != ERR_OK) {
          return ERR_FAILED;
      }
      if (FX1_WriteReg8(FX1_CTRL_REG_1, 0x0D) != ERR_OK) {
          return ERR_FAILED;
      }


  // get the X Y Z accelerometer values

        x = FX1_GetX();
        y = FX1_GetY();
        z = FX1_GetZ();


   printf("Accelerometer value \tX: %4d\t Y: %4d\t Z: %4d\n",x,y,z);
   //fprintf(values,"Accelerometer value \tX: %4d\t Y: %4d\t Z: %4d\n",x,y,z);
   for(xm=0;xm<=30000;xm++); //delay



// get the X Y Z magnetometer values

        if (FX1_GetMagX(&magX)!=ERR_OK) {
                  return ERR_OK;
              }
        if (FX1_GetMagY(&magY)!=ERR_OK) {
                         return ERR_OK;
                     }
        if (FX1_GetMagZ(&magZ)!=ERR_OK) {
                         return ERR_OK;
                     }


  printf("Magnetometer value \tX: %4d\t Y: %4d\t Z: %4d\n",magX,magY,magZ);
  //fprintf(values,"Magnetometer value \tX: %4d\t Y: %4d\t Z: %4d\n",magX,magY,magZ);
  for(xm=0;xm<=30000;xm++); //delay


  }

  //fclose(values);

  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
