/*
* Copyright (c) 2015 - 2016, Freescale Semiconductor, Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of Freescale Semiconductor, Inc. nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*! File: register_io_i2c.h
* @brief The \b register_io_i2c.h file declares low-level interface functions for reading
*  and writing sensor registers.
*/

#ifndef __REGISTER_IO_I2C_H__
#define __REGISTER_IO_I2C_H__

#include "sensor_drv.h"

/*!
 * @brief The interface function to write a sensor register.
 *
 * @param ARM_DRIVER_I2C *pCommDrv - The I2C driver to use.
 * @param uint16_t slaveAddress - the sensor's I2C slave address.
 * @param uint8_t offset - The register/offset to write to.
 * @param uint8_t *pBuffer - The buffer containing bytes to write.
 * @param uint8_t bytesToWrite - A number of bytes to write.
 *
 * @return ARM_DRIVER_OK if success or ARM_DRIVER_ERROR if error.
 */
int32_t Register_I2C_BlockWrite(
    ARM_DRIVER_I2C *pCommDrv, uint16_t slaveAddress, uint8_t offset, const uint8_t *pBuffer, uint8_t bytesToWrite);

/*!
 * @brief The interface function to write a sensor register.
 *
 * @param ARM_DRIVER_I2C *pCommDrv - The I2C driver to use.
 * @param uint16_t slaveAddress - the sensor's I2C slave address.
 * @param uint8_t offset - The register/offset to write to
 * @param uint8_t value - The value to write to the register
 * @param uint8_t mask - A mask value to use when writing.
 *                       A non-zero mask indicates that a read-modify-write operation should be used.
 *                       where only the bits set in the mask will be updated according to the value param.
 * @param bool repeatedStart - Indicates whether to send STOP or REPEATED_START bit after the write
 *
 * @return ARM_DRIVER_OK if success or ARM_DRIVER_ERROR if error.
 */
int32_t Register_I2C_Write(
    ARM_DRIVER_I2C *pCommDrv, uint16_t slaveAddress, uint8_t offset, uint8_t value, uint8_t mask, bool repeatedStart);

/*!
 * @brief The interface function to read a sensor register.
 *
 * @param ARM_DRIVER_I2C *pCommDrv - The I2C driver to use.
 * @param uint16_t slaveAddress - the sensor's I2C slave address.
 * @param uint8_t offset - The register/offset to read from
 * @param uint8_t length - The number of bytes to read
 * @param uint8_t *pOutBuffer - The pointer to the buffer to store the register value read.
 *
 * @return ARM_DRIVER_OK if success or ARM_DRIVER_ERROR if error.
 */
int32_t Register_I2C_Read(
    ARM_DRIVER_I2C *pCommDrv, uint16_t slaveAddress, uint8_t offset, uint8_t length, uint8_t *pOutBuffer);

#endif // __REGISTER_IO_I2C_H__
