/*
* Copyright (c) 2015 - 2016, Freescale Semiconductor, Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of Freescale Semiconductor, Inc. nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*! File: register_io_i2c.c
 * @brief The register_io_i2c.c file contains definitions for low-level interface functions
 *  for reading and writing sensor registers.
 */

/* Standard C Includes */
#include <string.h>

/* SDK Includes */
#include "Driver_SPI_SDK2.h"
#include "register_io_spi.h"

/*******************************************************************************
 * Functions
 ******************************************************************************/
/*! The interface function to block write sensor registers. */
int32_t Register_SPI_BlockWrite(
    ARM_DRIVER_SPI *pCommDrv, void *pWriteParams, uint8_t offset, const uint8_t *pBuffer, uint8_t bytesToWrite)
{
    int32_t status;
    spiCmdParams_t slaveWriteCmd;
    spiSlaveSpecificParams_t *pSlaveParams = pWriteParams;

    spiControlParams_t ss_en_cmd = {
        .cmdCode = ARM_SPI_SS_ACTIVE,
        .activeValue = pSlaveParams->ssActiveValue,
        .pTargetSlavePinID = pSlaveParams->pTargetSlavePinID,
    };
    spiControlParams_t ss_dis_cmd = {
        .cmdCode = ARM_SPI_SS_INACTIVE,
        .activeValue = pSlaveParams->ssActiveValue,
        .pTargetSlavePinID = pSlaveParams->pTargetSlavePinID,
    };

    pSlaveParams->pWritePreprocessFN(&slaveWriteCmd, offset, bytesToWrite, (void *)pBuffer);

    /*! Write and the value.*/
    pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_en_cmd);
    status = pCommDrv->Transfer(slaveWriteCmd.pWriteBuffer, slaveWriteCmd.pReadBuffer, slaveWriteCmd.size);
    pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_dis_cmd);

    return status;
}

/*! The interface function to write a sensor register. */
int32_t Register_SPI_Write(ARM_DRIVER_SPI *pCommDrv, void *pWriteParams, uint8_t offset, uint8_t value, uint8_t mask)
{
    int32_t status;
    uint8_t regValue;
    spiCmdParams_t slaveReadCmd, slaveWriteCmd;
    spiSlaveSpecificParams_t *pSlaveParams = pWriteParams;

    spiControlParams_t ss_en_cmd = {
        .cmdCode = ARM_SPI_SS_ACTIVE,
        .activeValue = pSlaveParams->ssActiveValue,
        .pTargetSlavePinID = pSlaveParams->pTargetSlavePinID,
    };
    spiControlParams_t ss_dis_cmd = {
        .cmdCode = ARM_SPI_SS_INACTIVE,
        .activeValue = pSlaveParams->ssActiveValue,
        .pTargetSlavePinID = pSlaveParams->pTargetSlavePinID,
    };

    /*! Set the register based on the values in the register value pair configuration.*/
    if (mask)
    {
        /* Get the formatted SPI Read Command. */
        pSlaveParams->pReadPreprocessFN(&slaveReadCmd, offset, 1);

        /*! Read the register value.*/
        pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_en_cmd);
        status = pCommDrv->Transfer(slaveReadCmd.pWriteBuffer, slaveReadCmd.pReadBuffer, slaveReadCmd.size);
        pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_dis_cmd);
        if (ARM_DRIVER_OK != status)
        {
            return status;
        }

        /*! 'OR' in the requested values to the current contents of the register */
        regValue = *(slaveReadCmd.pReadBuffer + pSlaveParams->spiCmdLen);
        regValue = (regValue & ~mask) | value;
    }
    else
    {
        /*! Overwrite the register with specified value.*/
        regValue = value;
    }

    pSlaveParams->pWritePreprocessFN(&slaveWriteCmd, offset, 1, &regValue);

    /*! Write and the value.*/
    pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_en_cmd);
    status = pCommDrv->Transfer(slaveWriteCmd.pWriteBuffer, slaveWriteCmd.pReadBuffer, slaveWriteCmd.size);
    pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_dis_cmd);

    return status;
}

/*! The interface function to read a sensor register. */
int32_t Register_SPI_Read(
    ARM_DRIVER_SPI *pCommDrv, void *pReadParams, uint8_t offset, uint8_t length, uint8_t *pOutBuffer)
{
    int32_t status;
    spiCmdParams_t slaveReadCmd;
    spiSlaveSpecificParams_t *pSlaveParams = pReadParams;

    spiControlParams_t ss_en_cmd = {
        .cmdCode = ARM_SPI_SS_ACTIVE,
        .activeValue = pSlaveParams->ssActiveValue,
        .pTargetSlavePinID = pSlaveParams->pTargetSlavePinID,
    };
    spiControlParams_t ss_dis_cmd = {
        .cmdCode = ARM_SPI_SS_INACTIVE,
        .activeValue = pSlaveParams->ssActiveValue,
        .pTargetSlavePinID = pSlaveParams->pTargetSlavePinID,
    };

    pSlaveParams->pReadPreprocessFN(&slaveReadCmd, offset, length);

    /*! Read the value.*/
    pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_en_cmd);
    status = pCommDrv->Transfer(slaveReadCmd.pWriteBuffer, slaveReadCmd.pReadBuffer, slaveReadCmd.size);
    pCommDrv->Control(ARM_SPI_CONTROL_SS, (uint32_t)&ss_dis_cmd);

    if (ARM_DRIVER_OK != status)
    {
        return status;
    }

    memcpy(pOutBuffer, slaveReadCmd.pReadBuffer + pSlaveParams->spiCmdLen, length);

    return status;
}
