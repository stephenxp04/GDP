/* ###################################################################
 **     Filename    : sonar.c
 **     Project     : sonar_baremetal3
 **     Processor   : MK64FN1M0VLL12
 **     Version     : Driver 01.01
 **     Compiler    : GNU C Compiler
 **     Date/Time   : 2016-11-19, 22:00, # CodeGen: 0
 **     Abstract    :
 **         Main module.
 **         This module contains user's application code.
 **     Settings    :
 **     Contents    :
 **         No public methods
 **
 ** ###################################################################*/
/*!
 ** @file sonar.c
 ** @version 01.01
 ** @brief
 **         Main module.
 **         This module contains user's application code.
 */
/*!
 **  @addtogroup main_module main module documentation
 **  @
 */
/* MODULE sonar */

#include "sonar.h"
#include "board.h"
#include "MK64F12.h"
#include "fsl_debug_console.h"


int ping_sonar(uint32_t pin_send , uint32_t pin_receive , uint32_t threshold )
{
	uint32_t count = 0;

	GPIO_WritePinOutput(GPIOC, pin_send, 0);
	delayUS(20U);
	GPIO_WritePinOutput(GPIOC, pin_send, 1);
	delayUS(10U);
	GPIO_WritePinOutput(GPIOC, pin_send, 0);
	delayUS(250U);

	while(GPIO_ReadPinInput(GPIOC, pin_receive) && count < threshold) //while sonar return readings
	{
		/*if(~((PTC->PDIR >> pin_receive) & 0x01U))
		{
			return 0;
			break;
		}
		else*/
			count++;
	}

	//GPIOC_PDOR |= (0<<pin_send);
	delay(20U);

	PRINTF("%d   " , count);    /*Print the text*/
	return count;
}

bool three_ping_sonar()
{
	int d1, d2, d3;

	d1 = ping_sonar(0U,1U,40000);
	delay(10U);
	d2 = ping_sonar(7U,8U,40000);
	delay(10U);
	d3 =ping_sonar(5U,9U,40000);
	delay(10U);

	if((d1+d2+d3) == 120000)
		return false;
	else
		return true ;
}

bool init_sonar()
{
	//SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;		/*Enable Port C Clock Gate Control*/
	//SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;

//	PORTC_PCR0  = 0X100;		/*sendpin */
	//PORTC_PCR5  = 0X100;
//	PORTC_PCR7  = 0X100;

	//PORTA_PCR4  = 0x100;
	GPIOA_PDDR |= (0 << 4);

	GPIOC_PDDR |= (1 << 0);
	GPIOC_PDDR |= (1 << 5);
	GPIOC_PDDR |= (1 << 7);

	GPIOC_PDOR |= (0 << 0);
	GPIOC_PDOR |= (0 << 5);
	GPIOC_PDOR |= (0 << 7);

	//////////////////////

	//PORTC_PCR1  = 0X100;		/*receive pin*/
	//PORTC_PCR8  = 0X100;
	//PORTC_PCR9  = 0X100;

	GPIOC_PDDR |= (0 << 1);
	GPIOC_PDDR |= (0 << 8);
	GPIOC_PDDR |= (0 << 9);

	///////////////////////

	PORTC_PCR6  = 0X100;
	GPIOC_PDDR |= (0 << 6);

    PRINTF("Sonar initialised.\r\n");
    return true;
}
