/*
 * Copyright (c) 2015 - 2016, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*! \file main_baremetal.c
    \brief Bare metal implementation of sensor fusion on FRDM-K64F.

    This file shows the recommended way to incorporate sensor fusion capabilities
    into a bare metal (no RTOS) project.
 */

// KSDK  and ISSDK Headers
#include "fsl_debug_console.h"  // KSDK header file for the debug interface
#include "board.h"              // KSDK header file to define board configuration
#include "pin_mux.h"            // KSDK header file for pin mux initialization functions
#include "clock_config.h"       // KSDK header file for clock configuration
#include "fsl_port.h"           // KSDK header file for Port I/O control
#include "fsl_uart.h"
#include "fsl_gpio.h"
#include "fsl_i2c.h"            // KSDK header file for I2C interfaces
#include "fsl_pit.h"            // KSDK header feile for Periodic Interval Timer
#include "Driver_I2C_SDK2.h"    // ISSDK CMSIS I2C Driver
#include "fxas21002.h"          // Register and bit-field definitions
#include "mpl3115.h"            // Register and bit-field definitions
#include "fxos8700.h"           // Register and bit-field definitions
#include "fsl_smc.h"
#include "uart.h"
#include "adc.h"
#include "sonar.h"

// Sensor Fusion Headers
#include "sensor_fusion.h"      // top level magCal and sensor fusion interfaces
#include "control.h"  	        // Command/Streaming interface - application specific
#include "status.h"   	        // Status indicator interface - application specific
#include "drivers.h"  	        // NXP sensor drivers OR customer-supplied drivers
#include "driver_pit.h"         // Project-specific - PIT is used to control main() timing loop

#include <stdio.h>
#include <string.h>

#include "ff.h"
#include "diskio.h"

#include "fsl_mpu.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* buffer size (in byte) for read/write operations */
#define BUFFER_SIZE (100U)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/*!
 * @brief Delay some time.
 *
 * @param milliseconds Time united in milliseconds.
 */
void delay(uint32_t milliseconds);
void delayUS(uint32_t microseconds);
void int16tostr (int32_t num, char* str_buff);
/*******************************************************************************
 * Variables
 ******************************************************************************/
static FATFS g_fileSystem; /* File system object */
static FIL g_fileObject;   /* File object */

// Global data structures
SensorFusionGlobals sfg;                ///< This is the primary sensor fusion data structure
struct ControlSubsystem controlSubsystem;      ///< used for serial communications
struct StatusSubsystem statusSubsystem;        ///< provides visual (usually LED) status indicator
struct PhysicalSensor sensors[3];              ///< This implementation uses up to 3 sensors

/*******************************************************************************
 * Code
 ******************************************************************************/
/* Delay some time united in milliseconds. */
void delay(uint32_t milliseconds)
{
	uint32_t i, j;

	for (i = 0; i < milliseconds; i++)
	{
		for (j = 0; j < 20000U; j++)
		{
			__asm("NOP");
		}
	}
}

void delayUS(uint32_t microseconds)
{
	uint32_t i, j;

	for (i = 0; i < microseconds; i++)
	{
		for (j = 0; j < 0x20; j++)
		{
			__asm("NOP");
		}
	}
}

/*FUNCTION*----------------------------------------------------------------
 *
 * Function Name  : int16tostr
 * Comments       : Converts a 16-bit integer number to a string
 *
 * Parameters:	[num] - 16-bit integer number
 * 		[str_buff] - Pointer to the output string
 *
 *END*--------------------------------------------------------------------*/

void int16tostr (int32_t num, char* str_buff)
{
	uint8_t		i = 0, j = 0;
	char		temp[10];

	if(num < 0)
	{
		num = -num;
		str_buff[0] = '-';
		j = 1;
	}

	while(num > 0)
	{
		temp[i++] = (char)((num % 10) + 0x30);
		num /= 10;
	}

	for(; i >= 1; j++, i--)
	{
		str_buff[j] = temp[i-1];
	}
	str_buff[j] = '\0';
}

/// This is a bare-metal implementation of the NXP sensor fusion demo build.
int main(void)
{
	FRESULT error;
	UINT bytesWritten;
	char		str_number[10];
	char		aux_string[100];
	const TCHAR driverNumberBuffer[3U] = {SDDISK + '0', ':', '/'};
	bool failedFlag = false;
	uint8_t flag1 = 0x31;
	uint8_t flag2 = 0x31;
	uint8_t flag3 = 0x31;
	uint8_t flag4 = 0x31;
	off_t new_line;
	UINT xa, ya, za, xm, ym, zm, xg, yg, zg;

	ARM_DRIVER_I2C* I2Cdrv = &I2C_S_DRIVER_BLOCKING;   // defined in the <shield>.h file
	uint16_t i=0;                       // general counter variable
	BOARD_InitPins();                   // defined in pin_mux.c, initializes pkg pins
	BOARD_BootClockRUN();               // defined in clock_config.c, initializes clocks
	BOARD_InitDebugConsole();           // defined in board.c, initializes the OpenSDA port
	I2Cdrv->Initialize(NULL);                                 // Initialize the KSDK driver for the I2C port

	I2Cdrv->Control(ARM_I2C_BUS_SPEED, ARM_I2C_BUS_SPEED_FAST);      // Configure the I2C bus speed

	PRINTF("RPI Enable signal waiting\n");
	//while(GPIO_ReadPinInput(GPIOC, 3U)){};

	while(!adc_init())
		flag1 = 0x31;
	while(!init_sonar())
		flag2 = 0x31;
	while(!uart3_init())
		flag3 = 0x31;
	while(!uart2_init())
		flag4 = 0x31;

	initializeControlPort(&controlSubsystem);                           // configure pins and ports for the control sub-system
	initializeStatusSubsystem(&statusSubsystem);                        // configure pins and ports for the status sub-system
	initSensorFusionGlobals(&sfg, &statusSubsystem, &controlSubsystem); // Initialize sensor fusion structures
	// "install" the sensors we will be using
#if F_USING_ACCEL || F_USING_MAG
	sfg.installSensor(&sfg, &sensors[0], FXOS8700_I2C_ADDR,  1, (void*) I2Cdrv, FXOS8700_Init,  FXOS8700_Read);
#endif
#if F_USING_GYRO
	sfg.installSensor(&sfg, &sensors[1], FXAS21002_I2C_ADDR, 1, (void*) I2Cdrv, FXAS21002_Init, FXAS21002_Read);
#endif
#if F_USING_PRESSURE
	sfg.installSensor(&sfg, &sensors[2], MPL3115_I2C_ADDR,   1, (void*) I2Cdrv, MPL3115_Init,   MPL3115_Read);
#endif
	sfg.initializeFusionEngine(&sfg);	        // This will initialize sensors and magnetic calibration

	pit_init(1000000/FUSION_HZ);                // pitIsrFlag will be set true at FUSION_HZ periodic intervals

	sfg.setStatus(&sfg, NORMAL);                // If we got this far, let's set status state to NORMAL

	MPU_Enable(MPU, false);

	PRINTF("\r\nPowerboat Safety Device 9 axis sensors test.\r\n");

	PRINTF("\r\nPlease insert a card into board.\r\n");
	/* Wait the card to be inserted. */
#if defined BOARD_SDHC_CD_LOGIC_RISING
	while (!(GPIO_ReadPinInput(BOARD_SDHC_CD_GPIO_BASE, BOARD_SDHC_CD_GPIO_PIN)))
	{
	}
#else
	while (GPIO_ReadPinInput(BOARD_SDHC_CD_GPIO_BASE, BOARD_SDHC_CD_GPIO_PIN))
	{
	}
#endif
	PRINTF("Detected SD card inserted.\r\n");
	/* Delay some time to make card stable. */
	delay(1000U);

	if (f_mount(&g_fileSystem, driverNumberBuffer, 0U))
	{
		PRINTF("Mount volume failed.\r\n");
		return -1;
	}

#if (_FS_RPATH >= 2U)
	error = f_chdrive((char const *)&driverNumberBuffer[0U]);
	if (error)
	{
		PRINTF("Change drive failed.\r\n");
		return -1;
	}
#endif

#if _USE_MKFS
	PRINTF("\r\nMake file system......The time may be long if the card capacity is big.\r\n");
	if (f_mkfs(driverNumberBuffer, 1U, 0U))
	{
		PRINTF("Make file system failed.\r\n");
		return -1;
	}
#endif /* _USE_MKFS */

	PRINTF("\r\nCreate a file in that directory......\r\n");
	error = f_open(&g_fileObject, _T("/log_data.txt"), (FA_WRITE | FA_READ | FA_CREATE_ALWAYS));
	if (error)
	{
		PRINTF("Open file failed.\r\n");
		return -1;
	}

	PRINTF("\r\nLog file created. Starting Sensor Fusion.\r\n");

	while (true)
	{
		//if(!Switch)
		if (true == pitIsrFlag) {               // Check whether occur interupt and toggle LED
			if (failedFlag)
			{
				break;
			}

			screen_sensors_report(flag1, flag2, flag3, flag4);
			delay(10);

			sfg.readSensors(&sfg, 1);           // Reads sensors, applies HAL and does averaging (if applicable)
			sfg.conditionSensorReadings(&sfg);  // magCal is run as part of this
			sfg.runFusion(&sfg);                // Run the actual fusion algorithms
			sfg.applyPerturbation(&sfg);        // apply debug perturbation (testing only)
			sfg.loopcounter++;                  // The loop counter is used to "serialize" mag cal operations
			i=i+1;
			if (i>=4) {                         // Some status codes include a "blink" feature.  This loop
				i=0;                        // should cycle at least four times for that to operate correctly.
				sfg.updateStatus(&sfg);     // This is where pending status updates are made visible
			}

			sfg.queueStatus(&sfg, NORMAL);      // assume NORMAL status for next pass through the loop
			//sfg.pControlSubsystem->stream(&sfg, sUARTOutputBuffer);      // Send stream data to the Sensor Fusion Toolbox

			//Multiply then divide again by the same number of bits to get the rounded up averaged values
			xa = (sfg.Accel.iGc[CHX] * 8192) / sfg.Accel.iCountsPerg;
			ya = (sfg.Accel.iGc[CHY] * 8192) / sfg.Accel.iCountsPerg;
			za = (sfg.Accel.iGc[CHZ] * 8192) / sfg.Accel.iCountsPerg;
			xm = (sfg.Mag.iBc[CHX] * 10) / (sfg.Mag.iCountsPeruT);
			ym = (sfg.Mag.iBc[CHY] * 10) / sfg.Mag.iCountsPeruT;
			zm = (sfg.Mag.iBc[CHZ] * 10) / sfg.Mag.iCountsPeruT;
			xg =  (sfg.Gyro.iYs[CHX] * 20) / sfg.Gyro.iCountsPerDegPerSec;
			yg = (sfg.Gyro.iYs[CHY] * 20) / (sfg.Gyro.iCountsPerDegPerSec);
			zg = (sfg.Gyro.iYs[CHZ] * 20) / (sfg.Gyro.iCountsPerDegPerSec);

			PRINTF("A %d %d %d M %d %d %d G %d %d %d\r\n", xa, ya, za, xm, ym, zm, xg, yg, zg);

			//PRINTF("Volt = %d\n\r", RotaryEnc());

			flag1 = (uint8_t)three_ping_sonar();

			error = f_open(&g_fileObject, _T("/log_data.txt"), (FA_WRITE | FA_OPEN_ALWAYS));
			if(error)
			{
				failedFlag = true;
				continue;
			}

			new_line = f_size(&g_fileObject);

			/* Move the file pointer */
			if (f_lseek(&g_fileObject, new_line))
			{
				//PRINTF("Set file pointer position failed. \r\n");
				failedFlag = true;
				continue;
			}

			aux_string[0] = '\0';
			strcat(aux_string, "A ");

			/* Append xa value */
			int16tostr(xa, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			/* Append ya value */
			int16tostr(ya, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			/* Append za value */
			int16tostr(za, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			strcat(aux_string, "M ");

			/* Append xm value */
			int16tostr(xm, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			/* Append ym value */
			int16tostr(ym, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			/* Append zm value */
			int16tostr(zm, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			strcat(aux_string, "G ");

			/* Append xg value */
			int16tostr(xg, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			/* Append yg value */
			int16tostr(yg, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, " ");

			/* Append zg value */
			int16tostr(zg, str_number);
			strcat(aux_string, str_number);
			strcat(aux_string, "\r\n");

			error = f_write(&g_fileObject, aux_string, strlen(aux_string), &bytesWritten);
			if (error)
			{
				//PRINTF("Write file failed. \r\n");
				failedFlag = true;
				continue;
			}

			if (f_close(&g_fileObject))
			{
				//PRINTF("\r\nClose file failed.\r\n");
				return -1;
			}

			//GPIO for RPi camera detection
			if(GPIO_ReadPinInput(GPIOC, 3U))
				PRINTF("Driver detected.\n");
			/* AP edit
			 *
			 *
			 * in this implementation, check for 2 out of the three flags == 1, if 2 flags are raised then shutdown
			 *
			 *	sonar	force	rpi    status
			 *	  0      0       0       F
			 *	  0		 0		 1       F
			 *	  0		 1		 0       T
			 *	  0      1       1       T
			 *	  1      0       0       F
			 *	  1      0       1       T
			 *	  1      1       0       T
			 *	  1      1       1       T
			 *
			 */

			/*
			  bool flag_adc = 0;
			  bool flag_rpi = 0;
			  bool flag_sonar = 0;

			  //flag == 1 when not detected

			  if(adc_read())
			  {flag_adc = 0;}
			  else
			  {flag_adc = 1;}

			  if(three_ping_sonar())
			  {flag_sonar=0;}
			  else
			  {flag_sonar=1;}

			  if(GPIO_ReadPinInput(GPIOC, 3U))
			  {flag_rpi = 0;}
			  else
			  {flag_rpi = 1;}

			  if(!adc_read() && !three_ping_sonar() && !GPIO_ReadPinInput(GPIOC, 3U) || flag_adc && flag_rpi || flag_adc && flag_sonar)
			  {
			  		shutdown_engine(); ////// need a function here for indication pueposes, one LED will suffice
			  	    send_gsm(); //send emergency signal
			        screen_shutdown_engine();
			        sd_write_log(shutdown);

			        while((throttle_read) && (steering_read) && (restart))
			        {
			         //loop while throttle read not 0, steering read not 0, pull-up restart input not 0
			        }
			        //break out when restart is initiated
			        screen_restart_engine();
			        sd_write_log(restart);
			  }

			  */


			pitIsrFlag = false;                 // Reset the flag for the next cycle


		}
	}

	return 0;
}
/// \endcode
